* RTC Gateway has to be set up on a PC accessible from the Internet.

* RTC Control is used by Developers and/or Support staff to provide remote support.