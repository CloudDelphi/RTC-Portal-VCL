* RTC Viewer is used by the Customer, when you are making remote presentations.
  RTC Viewer does not have any additional files and does no require installation.

* RTC Host is used by the Customer, when you need to provide remote support.
  RTC Host can use aw_sas32.dll for CAD and dfmirage for faster screen capture,
  and MouseA.dll + MouseA.sys files for mouse control on the UAC Screen. 
  Both options need to be enabled manually in Host Settings.  

* Optional files used by RTC Host:

  aw_sas32.dll -> has to be in the same folder as RtcHost.exe
                  to allow <Ctrl+Alt+Del> command to be executed on the Host

  dfmirage-setup -> can be installed on Customer PC to improve performance

  MouseA.dll & MouseA.sys -> have to be in the same folder as RTCHost.exe
                             to make mouse control possible on the UAC Screen